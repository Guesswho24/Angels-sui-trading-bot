// Entry point for React app
console.log('Sui Grid Bot Loaded');