# Sui Grid Bot Web App

This is the frontend for the grid trading bot using Sui Wallet & Slush Wallet.